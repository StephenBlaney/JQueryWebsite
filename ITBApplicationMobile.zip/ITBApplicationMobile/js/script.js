
$(document).bind('mobileinit',function(){
        $.mobile.changePage.defaults.changeHash = false;
        $.mobile.hashListeningEnabled = false;
        $.mobile.pushStateEnabled = false;
    });
	
$(document).ready(function() {
	
  $(document).on("pageshow", "[data-role='page']", function() {
    if ($($(this)).hasClass("header_default")) {
      $('<header data-theme="b" data-role="header"><h1></h1><a href="#home" data-transition = "flow" class="ui-btn-left ui-btn ui-btn-inline ui-btn-icon-notext ui-mini ui-corner-all ui-icon-home" data-rel="home">Home</a><a href="#mydialog" data-transition = "flow" class="ui-btn-right ui-btn ui-btn-inline ui-btn-icon-notext ui-mini ui-corner-all ui-icon-info">Info</a></header>')
        .prependTo( $(this) )
        .toolbar({ position: "fixed" });
        $("[data-role='header'] h1").text($(this).jqmData("title"));
    } //if header_default
    $.mobile.resetActivePageHeight();

    if ($($(this)).hasClass("footer_default")) {
      $('<footer data-theme="b" data-role="footer" data-position="fixed"><nav data-role="navbar"><ul><li><a href="#cources" data-transition = "flow" class="ui-btn ui-icon-edit ui-btn-icon-top">Cources</a></li><li><a href="#timetables" data-transition = "flow" class="ui-btn ui-icon-grid ui-btn-icon-top">Timetables</a></li><li><a href="#clubs" data-transition = "flow" class="ui-btn ui-icon-info ui-btn-icon-top">Clubs and Societies</a></li><li><a href="#sports" data-transition = "flow" class="ui-btn ui-icon-info ui-btn-icon-top">Sports and Fitness</a></li><li><a href="#maps" data-transition = "flow" class="ui-btn ui-icon-location ui-btn-icon-top">Maps</a></li><li><a href="#photos" data-transition = "flow" class="ui-btn ui-icon-camera ui-btn-icon-top">Photos</li></ul></nav></footer>')
        .appendTo($(this))
        .toolbar({position: "fixed"});
    }

    var current = $(".ui-page-active").attr('id');

    $("[data-role='footer'] a.ui-btn-active").removeClass("ui-btn-active");
    $("[data-role='footer'] a").each(function() {
      if ($(this).attr('href') === '#' + current) {
        $(this).addClass("ui-btn-active");
      }
    }); //each link in navbar

  }); //show_page
}); //document.ready


function jsonFlickrFeed(data) {

  var output = '';
  var list = ["This is the ITB library which is situated in the F block on campus. It has 2 floors and has 2 group areas and 2 quiet areas.","One of the great aspects of ITB is the free gym for students. Most colleges like DCU charge for the gym membership.","I have held the position of student president of ITB for the last 2 years. I run the student union with responsibilities such as listening to student issues. Speaking with the lectures on behalf of the students",
  "","","We are the 4th year class of 2013 in social care. We really enjoyed the experience of ITB with great approachable lecturers who where very helpful. We would recommend ITB for any perspective students","","I am a class rep from creative digital multimedia. I am currently in year 2. I love the role of class rep it gets you involved in the running of the college. My main responsibilities is to represent my class group and rasie any issues on their behalf.","This is the ITB shuttle bus which operates to get students to and from the train station and shopping centre. It runs every 30 mins during peak hours and every hour after.","","","The vice president responsibilities include The Welfare Officer covers a wide range of issues that" + 
  "affect the welfare of students, such as financial assistance, health, disability, childcare, accommodation, employment, safety and safe sex"];
  
  for (var i=0; i < data.items.length; i++) {
    var title = data.items[i].title;
    var link = data.items[i].media.m.substring(0,57);
    var blocktype = 
      ((i % 4) === 3) ? 'd':
      ((i % 4) === 2) ? 'c':
      ((i % 4) === 1) ? 'b':
      'a';
	
	var des = list[i];
	
    output += '<div class="ui-block-' + blocktype + '">';
    output += '<a href="#showphoto" data-transition="fade" onclick="showPhoto(\'' + link + '\',\'' + title + '\', \'' + des + '\')">';
    output += '<img src="' + link + '_q.jpg" alt="' + title + '">';
	
    output += '</a>';
    output += '</div>';
  }
  
  $('#photolist').html(output);
  
}

function showPhoto(link, title,description) {
  var output = '<a href="#photos" data-transition="fade">';
  
  output +='<img src="' + link +'_b.jpg" alt="' + title + '">';
  output +='</a>';
  output += '<p>' + description + '</p>';
 
  
  $('#myphoto').html(output);
  
}
function initMap() {
        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 7,
          center: {lat:  53.4051, lng:  - 6.3779}
        });
        directionsDisplay.setMap(map);

        var onChangeHandler = function() {
          calculateAndDisplayRoute(directionsService, directionsDisplay);
        };
        document.getElementById('start').addEventListener('change', onChangeHandler);
        document.getElementById('end').addEventListener('change', onChangeHandler);
      }

      function calculateAndDisplayRoute(directionsService, directionsDisplay) {
        directionsService.route({
          origin: document.getElementById('start').value,
          destination: document.getElementById('end').value,
          travelMode: 'DRIVING'
        }, function(response, status) {
          if (status === 'OK') {
            directionsDisplay.setDirections(response);
          } else {
            window.alert('Directions request failed due to ' + status);
          }
        });
      }







	  
	  







