var xhr = false;

function makeRequest() {
	if (window.XMLHttpRequest) {
		xhr = new XMLHttpRequest();
	}
	else {
		if (window.ActiveXObject) {
			try {
				xhr = new ActiveXObject("Microsoft.XMLHTTP");
				
			}
			catch (e) { }
		}
	}

	if (xhr) {
		var s = document.getElementById("studentno").value;
		xhr.onreadyStatechange = showContents;
		xhr.open("GET", "/user.json", true);
		xhr.send(null);
		
	}
	else {
		document.getElementById("#enterBtn").innerHTML = "Sorry, but I couldn't create an XMLHttpRequest"; 
	}
	
}

function showContents() {
	
	if (xhr.readyState == 4) {
	
		if (xhr.status == 200) {
		var jsondata = eval("(" + xhr.responseText + ")"); 
		var user = jsondata.users;
		var output = '';
		
		for(var i =0;i<user.length;i++){
		        if (document.getElementById("studentno").value == user[i].studentno && document.getElementById("password").value == user[i].password){
                    output = user[i].studentno;
                }
            }
        }
        if (output != '') {
            window.location.href = "#table";
        }
        else {
            alert("Wrong studentno or password!");
            window.location.href = "#timetables";
        }
    }
    else {
        var output = "There was a problem with the request " + xhr.status;
    }
}

